export function imprimirTarjetas(resultados, mediaRating){

    return resultados.map(resultado =>{


        const rating = parseFloat(resultado.imdbRating);
        let ratingIcono = '';
        if (!isNaN(rating)) {
            ratingIcono = rating >= mediaRating ? '👍' : '👎';
        }
        const actoresBadges = resultado.Actors.split(', ')
            .map(actor => `<span class="badge bg-secondary m-1">${actor}</span>`).join('');

        const generosBadges = resultado.Genre.split(', ')
            .map(genero => `<span class="badge bg-primary m-1">${genero}</span>`).join('');

        const paisesBadges = resultado.Country
            .map(pais => `<span class="badge bg-info m-1">${pais}</span>`).join('');

        const idiomaBadges = resultado.Language.split(', ')
            .map(idioma => `<span class="badge bg-warning text-dark m-1">${idioma}</span>`).join('');

        // Card Completa
        return `
    <div class="card mb-3" style="max-width: 740px;" data-card-id="${resultado.imdbID}">
        <div class="row g-0">
            <div class="col-md-4">
                <img src="${resultado.Images[0]}" class="img-fluid rounded-start" alt="Poster de ${resultado.Title}">
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title">${resultado.Title}</h5>
                    <p class="card-text"><strong>Rating:</strong> ${resultado.imdbRating} ${ratingIcono}</p>
                    <p class="card-text"><strong>Géneros:</strong> ${generosBadges}</p>
                    <p class="card-text"><strong>Actores:</strong> ${actoresBadges}</p>
                    <p class="card-text"><strong>País:</strong> ${paisesBadges}</p>
                    <p class="card-text"><strong>Idioma:</strong> ${idiomaBadges}</p>
                    
                    <button class="btn btn-dark btn-details" data-id="${resultado.imdbID}">Details</button>
                    
                    <div class="details-container mt-3"></div>
                </div>
            </div>
        </div>
    </div>
    `;
    }).join('');

}
