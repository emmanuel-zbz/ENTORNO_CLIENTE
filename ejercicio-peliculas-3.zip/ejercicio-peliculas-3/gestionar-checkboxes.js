import {genders} from "./filtrospelis.js";

document.addEventListener("DOMContentLoaded", () =>{
    const containerCheckboxes = document.getElementById("checkboxes");

    const generosOrdenados = [...genders].sort((a,b) => a.toLowerCase().localeCompare(b.toLowerCase()));
    const checkboxTodosHTML = `
    <label for="todos">Todos:</label>
    <input type="checkbox" id="todos" value="todos" name="generos">
    `;

    const checkboxesGeneros = generosOrdenados.map(genero =>{
        return `
        <label for="${genero}">${genero}:</label>
        <input type="checkbox" value="${genero}" name="generos">
        `;
    }).join('');

    containerCheckboxes.innerHTML = checkboxTodosHTML + checkboxesGeneros;

    const checkboxTodosEl = document.getElementById('todos');
    const generosCheckboxes = document.querySelectorAll('input[name="generos"]:not(#todos)');

    checkboxTodosEl.addEventListener('change', () => {
        // Obtener el estado (marcado/desmarcado) de "Todos"
        const estado = checkboxTodosEl.checked;

        // Aplicar ese mismo estado a todos los demás checkboxes
        generosCheckboxes.forEach(cb => {
            cb.checked = estado;
        });
    });

    generosCheckboxes.forEach(cb => {
        cb.addEventListener('change', () => {
            // Si desmarcamos un checkbox individual...
            if (!cb.checked) {
                // ...desmarcamos "Todos" automáticamente.
                checkboxTodosEl.checked = false;
            } else {
                // Si marcamos uno, comprobamos si TODOS están marcados
                const totalGeneros = generosCheckboxes.length;
                const totalMarcados = document.querySelectorAll('input[name="generos"]:not(#todos):checked').length;

                // Si el total de marcados es igual al total de géneros, marcamos "Todos"
                if (totalGeneros === totalMarcados) {
                    checkboxTodosEl.checked = true;
                }
            }
        });
    });
})