import {filtrarTitulo, filtrarActor, filtrarDirector, filtrarGeneros} from "./funciones-filtrado.js";

export function aplicarFiltros(peliculas, texto, criterio, generos) {

    let resultados = [...peliculas];

    if (criterio === "titulo"){
        resultados = filtrarTitulo(resultados, texto);
    }

    if (criterio === "director"){
        resultados = filtrarDirector(resultados, texto);
    }

    if (criterio === "actor"){
        resultados = filtrarActor(resultados, texto);
    }

    resultados = filtrarGeneros(resultados, generos);

    return resultados;
}