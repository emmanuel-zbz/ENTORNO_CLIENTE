import {pelis} from "./filmlist.js";

//Esta funcion sirve para filtrar por titulo de pelicula
export function filtrarTitulo(peliculas, titulo) {
    if (!peliculas) return peliculas;

    return peliculas.filter(pelicula => pelicula.Title.toLowerCase().includes(titulo.toLowerCase()));
}


//Funcion para filtrar por director
export function filtrarDirector(peliculas, director) {
    return peliculas.filter(pelicula => pelicula.Director.toLowerCase().includes(director.toLowerCase()));
}

//Funcion para filtrar por Actore
export function filtrarActor(peliculas, actor) {

    return peliculas.filter(pelicula => pelicula.Actors.toLowerCase().includes(actor.toLowerCase()));
}

//Funcion que filtra los generos
export function filtrarGeneros(peliculas, generosBuscados) {

    const generosEnMinusculas = generosBuscados.map(genero => genero.toLowerCase().trim());

    return peliculas.filter(pelicula =>{
        const generosDePelicula = pelicula.Genre.split(", ").map(g => g.toLowerCase().trim());

        return generosDePelicula.some(genero => generosEnMinusculas.includes(genero));
    });
}
