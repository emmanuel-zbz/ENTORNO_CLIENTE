import {pelis} from "./filmlist.js";
import {aplicarFiltros} from "./aplicarFiltros.js";
import {imprimirTarjetas} from "./imprimir-tarjetas.js";

document.addEventListener("DOMContentLoaded", () =>{
    //Primero cojo todo lo que vaya necesitar para gestionar el DOM
    const containerResultado = document.getElementById("resultado");
    const botonBuscar = document.getElementById("botonBuscar");


    const totalRatings = pelis
        .filter(p => p.imdbRating !== "N/A") // Filtrar las que no tienen rating
        .reduce((acc, p) => acc + parseFloat(p.imdbRating), 0);

    const mediaRating = totalRatings / pelis.filter(p => p.imdbRating !== "N/A").length;

    botonBuscar.addEventListener('click', () =>{
        let resultados = [...pelis];

        const texto = document.getElementById("texto");
        const elementoRadio = document.querySelector('input[name="criterioBusqueda"]:checked');
        const generosSeleccionados = Array.from(document.querySelectorAll('input[name="generos"]:checked'));

        const generosBuscados = generosSeleccionados.map(cb => cb.value);

        const textoBusqueda = texto.value.trim();

        const criterioBusqueda = elementoRadio? elementoRadio.value : null;

        const resultado = aplicarFiltros(resultados, textoBusqueda, criterioBusqueda,generosBuscados);

        const containerConteo = document.getElementById("conteo-resultados");
        containerConteo.innerHTML = `<strong>Encontradas: ${resultado.length} películas</strong>`;

        if (resultado.length === 0) {
            containerResultado.innerHTML = `<div class="alert alert-warning">No se encontraron películas con esos criterios.</div>`;
        } else {
            containerResultado.innerHTML = imprimirTarjetas(resultado, mediaRating); // Pasamos la media
        }
    });

    let tarjetaActivaActual = null; // Para rastrear qué tarjeta está seleccionada

    containerResultado.addEventListener('click', (e) => {

        // 1. Comprobar si el clic fue en un botón "Details"
        if (!e.target.classList.contains('btn-details')) {
            return; // Si no, ignorar el clic
        }

        // 2. Obtener los elementos necesarios
        const boton = e.target;
        const peliId = boton.dataset.id;
        const peli = pelis.find(p => p.imdbID === peliId);
        const cardClicada = boton.closest('.card'); // La tarjeta que se clicó
        const detailsContainer = cardClicada.querySelector('.details-container');

        // 3. Gestionar la tarjeta anterior (el requisito del examen)
        // Si ya había una tarjeta activa (bg-info) Y NO es la misma que acabo de clicar...
        if (tarjetaActivaActual && tarjetaActivaActual !== cardClicada) {
            // ...le quito el color y limpio su contenido
            tarjetaActivaActual.classList.remove('bg-info');
            tarjetaActivaActual.querySelector('.details-container').innerHTML = '';
        }

        // 4. Usar toggle en la tarjeta actual (tu sugerencia)
        // classList.toggle devuelve 'true' si añadió la clase, 'false' si la quitó.
        const seAcabaDeActivar = cardClicada.classList.toggle('bg-info');

        if (seAcabaDeActivar) {
            // Si se acaba de activar, mostramos los detalles
            detailsContainer.innerHTML = `<pre>${JSON.stringify(peli, null, 2)}</pre>`;
            tarjetaActivaActual = cardClicada; // La guardamos como la nueva activa
        } else {
            // Si se acaba de desactivar (porque la clicamos de nuevo)
            detailsContainer.innerHTML = '';
            tarjetaActivaActual = null; // Ya no hay ninguna activa
        }
    });
})