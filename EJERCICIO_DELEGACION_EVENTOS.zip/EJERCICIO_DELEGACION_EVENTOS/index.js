document.addEventListener("DOMContentLoaded", () =>{
    const tablaEl = document.querySelector("#colorTable");
    const tagEl = document.querySelector("#tag");
    const cellIdEl = document.querySelector("#cell-id");
    const cellEl = document.querySelector("#text-content");
    const rowEl = document.querySelector("#row-content");
    const columnEl = document.querySelector("#column-content");
    const positionXEl = document.querySelector("#position-x");
    const positionYEl = document.querySelector("#position-y");

    tablaEl.addEventListener("click", (e) =>{
        tagEl.textContent = `${e.target.tagName}`;
        cellIdEl.textContent = `${e.target.id}`;
        cellEl.textContent = `${e.target.textContent}`;
        rowEl.textContent = `${e.target.parentElement.rowIndex + 1}`;
        columnEl.textContent = `${e.target.cellIndex + 1}`;
        positionXEl.textContent = `X: ${e.clientX}`;
        positionYEl.textContent = `Y: ${e.clientY}`;
    });

    tablaEl.addEventListener("mouseover", (e) =>{
        if(e.target.tagName === "TD"){
            e.target.classList.add("rojo");
        }
    })

    tablaEl.addEventListener("mouseout", (e) =>{
        if(e.target.tagName === "TD"){
            e.target.classList.remove("rojo");

        }
    })


})