const personas =[
    {name: "Jon", surname: "Doe", age: 12, alive: true},
    {name: "Jane", surname: "Done", age: 3, alive: true},
    {name: "Foo", surname: "Bar", age: 33, alive: true},
    {name: "Mario", surname: "Mariolini", age: 35, alive: false}
]
const generarFilaHTML = (persona) =>{
    const {name, surname, age, alive} = persona;
    const aliveIcon = alive ? "✓" : "x";
    return `<tr data-ediciones="0">
                    <td>${name}</td>
                    <td>${surname}</td>
                    <td>${age}</td>
                    <td>${aliveIcon}</td>
                    <td><button>Borrar</button></td>
                </tr>`;
}
const renderTabla = (arrayPersonas) =>{
    return arrayPersonas.map(persona => generarFilaHTML(persona)).join("");
}

const limpiarTabla = fila =>{
    fila.forEach(celda => celda.classList.remove('table-active'));
}

document.addEventListener("DOMContentLoaded", () =>{
    const tbodyEl = document.querySelector("#table-body");
    const inputNameEl = document.querySelector("#name");
    const inputSurnameEl = document.querySelector("#surname");
    const inputAgeEl = document.querySelector("#age");
    const inputAliveEl = document.querySelector("#alive");
    const botonFormEl = document.querySelector("#boton-formulario");

    let indice = null;

    tbodyEl.addEventListener("click", (e) =>{
        const row = e.target.closest('tr');

        const todasLasFilas = tbodyEl.querySelectorAll("tr");

        limpiarTabla(todasLasFilas);
        row.classList.add('table-active');

         indice = row.rowIndex - 1;
        const {name, surname, age, alive} = personas[indice];

        inputNameEl.value = name;
        inputSurnameEl.value = surname;
        inputAgeEl.value = age;
        inputAliveEl.checked = alive;
        botonFormEl.textContent = "Editar";
    });

    botonFormEl.addEventListener("click", (e) => {
        e.preventDefault();
        if (e.target.textContent === "Editar"){
            personas[indice].name = inputNameEl.value;
            personas[indice].surname = inputSurnameEl.value;
            personas[indice].age = inputAgeEl.value;
            personas[indice].alive = inputAliveEl.checked;
            const filaVisual = tbodyEl.children[indice];
            filaVisual.children[0].textContent = personas[indice].name;
            filaVisual.children[1].textContent = personas[indice].surname;
            filaVisual.children[2].textContent = personas[indice].age;
            filaVisual.children[3].textContent = personas[indice].alive ? "✓": "X";
            const todasLasFilas = tbodyEl.querySelectorAll("tr");
            limpiarTabla(todasLasFilas);
        } else{
            const persona = {
                name: inputNameEl.value,
                surname: inputSurnameEl.value,
                age: inputAgeEl.value,
                alive: inputAliveEl.checked
            }
            personas.push(persona);
            tbodyEl.insertAdjacentHTML("beforeend", generarFilaHTML(persona));
        }
        e.target.form.reset();

    })

    tbodyEl.innerHTML = renderTabla(personas);
})