const comidas = {
    Italian: ["Pasta", "Pizza", "Penne", "Focaccia"],
    American: ["Burger", "Fries"],
    Spanish: ["Paella", "Tortilla", "Cocido", "Gazpacho"]
}

const comprobarNombreYApellido = texto => {
    const palabras = texto.trim().split(/\s+/);
    const tieneDosPalabras = palabras.length >= 2;
    const tieneLongitudMinima = texto.replaceAll(" ", "").length >= 7;
    return tieneDosPalabras && tieneLongitudMinima;
}

function procesarDataList(tipo) {
    return comidas[tipo].map(comida => {
        return `<option value="${comida}">${comida}</option>`
    }).join("");
}

document.addEventListener("DOMContentLoaded", () => {
    const inputNameElement = document.querySelector("#inputName");
    const errorInputNameElement = document.querySelector("#nameError");

    const inputAgeElement = document.querySelector("#inputAge");

    const checkboxAllElement = document.querySelector("#checkAll");
    const checkboxesNodeList = document.querySelectorAll(".hobby-item");

    const selectFoodsElement = document.querySelector("#foodCategory");
    const inputFlavorElement = document.querySelector("#inputFlavor");
    const dataListElement = document.querySelector("#datalistOptions");

    const inputCardNumberElement = document.querySelector("#ccNumber");
    const inputCVCElement = document.querySelector("#ccCvc");

    inputNameElement.addEventListener("change", (e) => {
        const regex = /[0-9]/;
        const tieneNumeros = regex.test(e.target.value);
        const tieneNombreApellidosValido = comprobarNombreYApellido(e.target.value);

        if (tieneNumeros || !tieneNombreApellidosValido) {
            errorInputNameElement.textContent = "Campo no valido";
            inputNameElement.classList.remove("is-valid");
            inputNameElement.classList.add("is-invalid");
        } else {
            inputNameElement.classList.remove("is-invalid");
            inputNameElement.classList.add("is-valid");
            inputNameElement.value = inputNameElement.value.split(/\s+/)
                .map(palabra => palabra.charAt(0).toUpperCase() + palabra.slice(1)).join(" ");
        }

    });

    inputAgeElement.addEventListener("input", (e) => {
        const valor = e.target.value;

        const esNumeroValido = /^\d+$/.test(valor);
        if (esNumeroValido) {
            inputAgeElement.classList.remove("is-invalid");
            inputAgeElement.classList.add("is-valid");
        } else {
            inputAgeElement.classList.remove("is-valid");
            inputAgeElement.classList.add("is-invalid");
        }
    });

    checkboxAllElement.addEventListener("change", (e) => {
        checkboxesNodeList.forEach(checkbox => checkbox.checked = e.target.checked);
    });

    checkboxesNodeList.forEach(checkbox => {
        checkbox.addEventListener("change", () => {
            const numeroTotalCheckboxes = checkboxesNodeList.length;
            const numeroCheckboxesMarcados = document.querySelectorAll(".hobby-item:checked").length;
            checkboxAllElement.checked = numeroCheckboxesMarcados === numeroTotalCheckboxes;
        });
    });

    selectFoodsElement.addEventListener("change", (e) => {
        inputFlavorElement.removeAttribute("disabled");
        inputFlavorElement.value = "";

        dataListElement.innerHTML = procesarDataList(e.target.value);
    });

    inputCardNumberElement.addEventListener("input", (e) =>{

        e.target.value = e.target.value.replaceAll(" ", "").match(/.{1,4}/g).join(" ");
    })

    inputCVCElement.addEventListener("input", (e) =>{
        const valor = e.target.value;
        const esNumeroEntero = /^\d+$/.test(valor);
        if (!esNumeroEntero || e.target.value.length > 3){
            e.target.value = e.target.value.slice(0, -1);
        }
    });

})
