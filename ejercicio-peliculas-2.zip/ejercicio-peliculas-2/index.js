import {buscarDirector, buscarActor, buscarTitulo, buscarGenero} from "./funciones-filtrado.js";
import {pelis} from "./filmlist.js";
import {generarHTMLResultados} from "./render.js";

document.addEventListener("DOMContentLoaded", () => {

    const botonBuscar = document.querySelector('input[type="button"][value="buscar"]');

    botonBuscar.addEventListener('click', () => {
        const textoBuscado = document.getElementById("textoBuscar").value.trim();
        const divResultado = document.getElementById("resultados");
        const elementoRadio = document.querySelector('input[name="criteroBusqueda"]:checked');

        if (!elementoRadio) {
            // Si no existe, mostrar error y salir.
            divResultado.innerHTML = "<p>Por favor, selecciona un criterio de búsqueda (Título, Director o Actor).</p>";
            return; // Detiene la ejecución aquí
        }

        const radioSeleccionado = elementoRadio.value;
        const generosBuscados = Array.from(document.querySelectorAll('input[name="generos"]:checked')).map(checkbox => checkbox.value);


        let resultados = [...pelis];
        if (radioSeleccionado === "titulo") {

            resultados = buscarTitulo(resultados, textoBuscado);

        } else if (radioSeleccionado === "director") {
            resultados = buscarDirector(resultados, textoBuscado);
        } else {
            resultados = buscarActor(resultados, textoBuscado);
        }
        const hayGeneros = generosBuscados.length > 0;
        const noBuscaTodos = !generosBuscados.includes("todos");

        if (hayGeneros && noBuscaTodos) {
            resultados = buscarGenero(resultados, generosBuscados);
        }


        divResultado.innerHTML = generarHTMLResultados(resultados);
    })
})
