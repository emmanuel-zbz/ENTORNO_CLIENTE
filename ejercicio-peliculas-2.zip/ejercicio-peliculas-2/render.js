export function generarHTMLResultados(resultados) {

    if (resultados.length === 0) {
        return `<p>No se encontraron resultados</p>`
    }

    const listaHTML = resultados.map(resultado => {
        return `
          <div class="card" style="width: 18rem;">
            <img src="${resultado.Poster}" class="card-img-top" alt="poster">
            <div class="card-body">
                <h5 class="card-title">${resultado.Title}</h5>
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item">${resultado.Director}</li>
                <li class="list-group-item">${resultado.Actors}</li>
                <li class="list-group-item">${resultado.Genre}</li>
            </ul>
        </div>
        `;
    }).join('');

    return `<h3>${resultados.length} Resultados encontrados:</h3><div class="lista-peliculas">${listaHTML}</div>`;
}
