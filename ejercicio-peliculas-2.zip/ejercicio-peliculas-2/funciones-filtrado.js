import {pelis} from "./filmlist.js";

export function buscarTitulo(peliculas, titulo){
    if (!peliculas) return peliculas;

    return peliculas.filter(pelicula => pelicula.Title.toLowerCase().includes(titulo.toLowerCase()));
}

export function buscarDirector(peliculas, nombreDirector){
    if (!peliculas) return peliculas;

    return peliculas.filter(pelicula => pelicula.Director.toLowerCase().includes(nombreDirector.toLowerCase()));
}

export function buscarActor(peliculas, nombreActor){
    if (!peliculas) return peliculas;

    return peliculas.filter(pelicula => pelicula.Actors.toLowerCase().includes(nombreActor.toLowerCase()));
}

export function buscarGenero(peliculas, generosBuscados){
    if (!peliculas) return peliculas;


    const generosBuscadosLower = generosBuscados.map(g => g.toLowerCase());
    return peliculas.filter(pelicula =>{
        const generosPelicula = pelicula.Genre.split(', ').map(g => g.trim().toLowerCase());

        return generosBuscadosLower.some(generosBuscado => generosPelicula.includes(generosBuscado));
    })
}
