import {Component, signal} from '@angular/core';
import {FormsModule} from "@angular/forms";

@Component({
  selector: 'app-ex06',
  standalone: true,
  imports: [
    FormsModule
  ],
  templateUrl: './ex06.component.html',
  // styleUrl: './ex06.component.css'
})
export class Ex06Component {
  celcius = signal(0);
  fahrenheit = signal(5550);


  clear() {
    this.celcius.set(0);
    this.fahrenheit.set(0);
  }

  convertToCelcius() {
    this.celcius.set((this.fahrenheit() - 32) * 5 / 9);
  }

  converToFahrenheit() {
    this.fahrenheit.set(this.celcius() * 9 / 5 + 32);
  }
}
