import {Component, signal} from '@angular/core';
import {UpperCasePipe} from "@angular/common";
import {FormsModule} from "@angular/forms";

@Component({
  selector: 'app-ex05',
  standalone: true,
  imports: [
    UpperCasePipe,
    FormsModule
  ],
  templateUrl: './ex05.component.html',
  styleUrl: './ex05.component.css'
})
export class Ex05Component {
  word = signal("este es el texto...")


  clearWord() {
    this.word.set("");
    setTimeout(() => this.word.set("ya hay algo"), 2000);
  }
}
