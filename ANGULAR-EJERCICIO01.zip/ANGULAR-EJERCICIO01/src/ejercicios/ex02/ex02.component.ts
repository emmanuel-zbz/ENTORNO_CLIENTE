import {Component, signal} from '@angular/core';
import {JsonPipe, UpperCasePipe} from "@angular/common";
import {Person} from '../../models/person.model';


@Component({
  selector: 'app-ex02',
  standalone: true,
  imports: [
    JsonPipe,
    UpperCasePipe
  ],
  templateUrl: './ex02.component.html',
  styleUrl: './ex02.component.css'
})

export class Ex02Component {
  x = signal(23);
  y = signal(9);
  word = signal("meetup");

  person = signal<Person>({
    name: "Alan brito",
    position: "full-stack dev",
    salary: 2000
  });


}
