import {Component, signal} from '@angular/core';

@Component({
  selector: 'app-ex07',
  standalone: true,
  imports: [],
  templateUrl: './ex07.component.html'
})
export class Ex07Component {
  numbers = signal<number[]>([1, 5, 8, 24, 32, 11, 55]);
  fruits = signal<string[]>(["pear", "apple", "mango", "watermelon", "kiwi"]);


}
