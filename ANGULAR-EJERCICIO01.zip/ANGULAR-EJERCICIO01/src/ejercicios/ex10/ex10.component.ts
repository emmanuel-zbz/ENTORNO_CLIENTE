import {Component, signal} from '@angular/core';

@Component({
  selector: 'app-ex10',
  standalone: true,
  imports: [],
  templateUrl: './ex10.component.html'
})

export class Ex10Component {
  temperature = signal(Math.floor(Math.random() * 20 + 1));

  incTemp(inc: number) {
    this.temperature.update(value => value + inc);
  }
}
