import {Component, signal} from '@angular/core';
import {Employee} from "../../models/employee";
import {EMPLOYEE_LIST} from "../../models/employee-list";

@Component({
  selector: 'app-ex09',
  standalone: true,
  imports: [],
  templateUrl: './ex09.component.html'
})
export class Ex09Component {
  employees = signal<Employee[]>(EMPLOYEE_LIST);

}
