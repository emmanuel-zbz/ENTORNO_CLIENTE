import {Component, signal} from '@angular/core';

@Component({
  selector: 'app-ex04',
  standalone: true,
  imports: [],
  templateUrl: './ex04.component.html',
  styleUrl: './ex04.component.css'
})
export class Ex04Component {
  n = signal(100);


  setNumber() {
    this.n.set(Math.floor(Math.random() * 10 + 1));
  }

  incNumber() {
    this.n.update((currentValue) => currentValue + 1);
  }

  decNumber() {
    this.n.update((currentValue) => currentValue - 1);
  }
}
