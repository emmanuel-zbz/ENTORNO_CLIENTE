import {Component, signal} from '@angular/core';
import {FormsModule} from "@angular/forms";

@Component({
  selector: 'app-ex08',
  standalone: true,
  imports: [

    FormsModule
  ],
  templateUrl: './ex08.component.html'
})
export class Ex08Component {
  numbers = signal<number[]>([1, 5, 8, 24, 32, 11, 55]);
  fruits = signal<string[]>(["pear", "apple", "mango", "watermelon", "kiwi"]);

  num = signal(1000);
  fruit = signal('lichi');


  insNumber() {
    this.numbers.update(value => [...value, this.num()])
    this.num.set(0);
  }

  insFruit() {
    this.fruits.update(value => [...value, this.fruit()]);
    this.fruit.set('');
  }
}
